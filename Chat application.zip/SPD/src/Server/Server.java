package Server;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.PrimitiveIterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.SSLSocket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Nayeem
 */
public class Server {

    static ArrayList<Socket> SO = new ArrayList<Socket>(10);
    static int ssr = 0;

    public static void main(String[] args) {

        int n = 0;
        try {
            ServerSocket SSS = new ServerSocket(8900);
            while (true) {
                Socket S = SSS.accept();
                n++;
                SO.add(S);
                BufferedReader R = new BufferedReader(new InputStreamReader(S.getInputStream()));
                PrintWriter W = new PrintWriter(S.getOutputStream(), true);
                Cre_Log T = new Cre_Log(S);
                T.start();
            }

        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}

class Cre_Log extends Thread {

    Socket S;

    public Cre_Log(Socket S) {
        this.S = S;
    }

    @Override
    public void run() {

        try {
            BufferedReader R = new BufferedReader(new InputStreamReader(S.getInputStream()));
            PrintWriter W = new PrintWriter(S.getOutputStream(), true);
            BufferedReader fr = new BufferedReader(new FileReader("Login.txt"));
            PrintWriter fw = new PrintWriter(new FileWriter("Login.txt"), true);

            while (true) {
                int a = Integer.parseInt(R.readLine());
                int flg = -1;
                switch (a) {

                    case 0:
                        String s = R.readLine();
                        fw.append("").print(s);
                        s = R.readLine();
                        fw.append(" ").print(s);
                        s = R.readLine();
                        fw.append(" ").print(s);
                        s = R.readLine();
                        fw.append(" ").print(s);
                        s = R.readLine();
                        fw.append(" ").println(s);

                        break;

                    case 1:
                        s = R.readLine();
                        String s1 = R.readLine();
                        String s2 = fr.readLine();

                        while (s2 != null) {
                            String sp[] = s2.split(" ");
                            if (sp[0].equals(s) && sp[1].equals(s1)) {
                                flg = 1;
                                break;
                            } else {
                                flg = -1;
                            }
                            s2 = fr.readLine();
                        }
                        fr = new BufferedReader(new FileReader("Login.txt"));
                        W.println("" + flg);

                        break;

                }
                if (flg == 1) {
                    
                    break;
                }
            }
            String name =R.readLine();
            rd_wr rw =new rd_wr(S, name);
            rw.start();

        } catch (IOException ex) {
            Logger.getLogger(Cre_Log.class.getName()).log(Level.SEVERE, null, ex);

        }

    }
}

class rd_wr extends Thread {

    Socket s;
    String name;

    public rd_wr(Socket s, String name) {
        this.s = s;
        this.name = name;
    }

    @Override
    public void run() {
        try {
            //To change body of generated methods, choose Tools | Templates.
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(s.getInputStream())
            );
            int flag = -1;
            nam();
            while (true) {
                String clc = "&&$";
                String a = in.readLine();
                if (a.contains(clc)) {
                    String[] sp = a.split(" ");
                    if (Integer.parseInt(sp[1]) < 0 || Integer.parseInt(sp[1]) > Server.ssr) {
                        out.println("client not connected");
                    } else {
                        flag = Integer.parseInt(sp[1]) - 1;
                        out.println("ms will send to client " + (flag + 1) + " ONly");
                    }

                } else if (flag != -1) {
                    Socket ss = Server.SO.get(flag);
                    PrintWriter uut = new PrintWriter(ss.getOutputStream(), true);
                    uut.println(name + ": " + a);
                } else {
                    for (Socket x : Server.SO) {
                        if (x != s) {
                            Socket ss = x;
                            PrintWriter uut = new PrintWriter(ss.getOutputStream(), true);
                            uut.println(name + ": " + a);
                        }
                    }
                }
                /* if (SErver.SO.get(0).equals(s)) {
                    Socket ss = SErver.SO.get(1);
                    PrintWriter uut = new PrintWriter(ss.getOutputStream(), true);

                    uut.println(a);
                } else {
                    Socket ss = SErver.SO.get(0);
                    PrintWriter uut = new PrintWriter(ss.getOutputStream(), true);

                    uut.println(a);
                }*/

            }
        } catch (IOException ex) {
            Logger.getLogger(rd_wr.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    public void nam()
    {
        try {
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            out.println(this.name);
        } catch (IOException ex) {
            Logger.getLogger(rd_wr.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
